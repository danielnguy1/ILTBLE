import math
import serial
import matplotlib.pyplot as plt
import codecs
import numpy as np
from pyqtgraph.Qt import QtGui, QtCore
import pyqtgraph as pg
import sys

def argsort(seq):
    #http://stackoverflow.com/questions/3382352/equivalent-of-numpy-argsort-in-basic-python/3382369#3382369
    #by unutbu
    return sorted(range(len(seq)), key=seq.__getitem__)

pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')

# Generate random points
n = 1000
print('Number of points: ' + str(n))
datap = np.random.normal(size=(2, n))

# Create the main application instance
app = QtGui.QApplication(sys.argv)  # Create QApplication ***

# Create the view
view = pg.PlotWidget()
view.resize(800, 600)
view.setWindowTitle('Scatter plot using pyqtgraph with PyQT5')
view.setAspectLocked(True)
view.show()

scatter = pg.ScatterPlotItem(pen=pg.mkPen(width=5, color='r'), symbol='o', size=1)
view.addItem(scatter)

arrayDisp = []
arrayProximity = []
arrayAddress = []
arrayRSSI = []
RSSI = []
arrayRSSI_last5 = []
plt.ion()
arrayRSSI_movingAvg = []
trilat_dist1 = []
trilat_dist2 = []
trilat_dist3 = []
delta = []
A = []
B = []
x0 = []
y0 = []
def makeFig():
    plt.plot(RSSI,'ro-')
corx1 = []
cory1 = []
corx2 = []
cory2 = []
corx3 = []
cory3 = []
corx1.append(0)
cory1.append(0)
corx2.append(0)
cory2.append(0)
corx3.append(0)
cory3.append(0)
trilat_dist1.append(0)
trilat_dist2.append(0)
trilat_dist3.append(0)
delta.append(0)
A.append(0)
B.append(0)
x0.append(0)
y0.append(0)
initial = 1000.0
N= 5
matrix = []
matrix.append([])
matrix[0].append(initial)
accumulatedDisp = []
accumulatedDisp.append(0)
trilatrad = []
trilatrad.append([])
trilatrad[0].append(0)
trilatrad[0].append(0)
trilatrad[0].append(0)



def plot(x,y,radius):
    # Convert data array into a list of dictionaries with the x,y-coordinates
    dispx =np.array([1.660349753291821e+92,1.7660349753291821e+92,3.660349753291821e+92])
    dispy = np.array([-1.660349753291821e+92, -1.7660349753291821e+92, -3.660349753291821e+92])
    scatter.setData(x,y,size=50)

    #scatter.addPoints(dispx,dispy,size=[100,300,200])
    # Gracefully exit the application
    app.processEvents()


tog = 0
j = 1

while(1):
    if(tog==0):
        data = "@D1,1,A1:B2,80"
        tog=tog+1
    elif tog==1:
        data = "@D3,1,A1:B2,78"
        tog = tog + 1
    elif tog==2:
        data = "@D2,1,G1:B2,79"
        tog = tog + 1
    elif tog==3:
        data = "@D3,1,G1:B2,75"
        tog = tog + 1
    elif tog==4:
        data = "@D2,1,F0:B2,79"
        tog = tog + 1
    elif tog==5:
        data = "@D4,1,F0:B2,82"
        tog = tog + 1
    elif tog==6:
        data = "@D4,1,G1:B2,75"
        tog = tog + 1
    elif tog==7:
        data = "@D2,1,E2:B9,79"
        tog = tog + 1
    else:
        data = "@D1,1,F0:B2,70"
        tog=0

    if data.find('@D') != -1:
        data = data.replace("@D", '')
        recvData = data.split(',')
        arrayDispNo = recvData[0]
        arrayProximity = recvData[1]
        arrayAddress = recvData[2]
        arrayRSSI = recvData[3]
        #print(recvData)

    for i in range(len(matrix)):  # len(input) # rows len(input[0]) # columns eg. ([1,2],[2,3],[4,1]) 3 rows 2 cols
        if arrayAddress == matrix[i][0]:
            arrayRSSI_last5[i].pop(0)
            arrayRSSI_last5[i].append(int(arrayRSSI))
            arrayRSSI_movingAvg[i] = sum(arrayRSSI_last5[i]) / 5
            if matrix[i][int(float(arrayDispNo))] == initial:
                accumulatedDisp[i] = accumulatedDisp[i] + 1
            matrix[i][int(float(arrayDispNo))] = float(arrayRSSI_movingAvg[i])

            break
        elif matrix[i][0] == initial:
            matrix[i][0] = arrayAddress
            matrix[i].append(initial);
            matrix[i].append(initial);
            matrix[i].append(initial);
            matrix[i].append(initial)

            arrayRSSI_last5.append([])
            arrayRSSI_last5[i].append(0)
            arrayRSSI_last5[i].append(0)
            arrayRSSI_last5[i].append(0)
            arrayRSSI_last5[i].append(0)
            arrayRSSI_last5[i].append(0)
            arrayRSSI_last5[i].pop(0)
            arrayRSSI_last5[i].append(int(arrayRSSI))
            arrayRSSI_movingAvg.append([])
            if matrix[i][int(float(arrayDispNo))] == initial:
                accumulatedDisp[i] = accumulatedDisp[i] + 1
            matrix[i][int(float(arrayDispNo))] = float(arrayRSSI)
            break
        elif i == len(matrix) - 1:
            matrix.append([])
            accumulatedDisp.append(0)
            matrix[len(matrix) - 1].append(arrayAddress)
            matrix[len(matrix) - 1].append(initial);
            matrix[len(matrix) - 1].append(initial);
            matrix[len(matrix) - 1].append(initial);
            matrix[len(matrix) - 1].append(initial);
            arrayRSSI_last5.append([])
            arrayRSSI_last5[len(matrix) - 1].append(0)
            arrayRSSI_last5[len(matrix) - 1].append(0)
            arrayRSSI_last5[len(matrix) - 1].append(0)
            arrayRSSI_last5[len(matrix) - 1].append(0)
            arrayRSSI_last5[len(matrix) - 1].append(0)
            arrayRSSI_last5[len(matrix) - 1].pop(0)
            arrayRSSI_last5[len(matrix) - 1].append(float(arrayRSSI))
            arrayRSSI_movingAvg.append([])
            arrayRSSI_movingAvg[len(matrix) - 1] = sum(arrayRSSI_last5[len(matrix) - 1]) / 5
            if matrix[len(matrix) - 1][int(float(arrayDispNo))] == initial:
                accumulatedDisp[len(matrix) - 1] = accumulatedDisp[len(matrix) - 1] + 1
            matrix[len(matrix) - 1][int(float(arrayDispNo))] = float(arrayRSSI_movingAvg[len(matrix) - 1])
            corx1.append(0)
            cory1.append(0)
            corx2.append(0)
            cory2.append(0)
            corx3.append(0)
            cory3.append(0)
            trilat_dist1.append(0)
            trilat_dist2.append(0)
            trilat_dist3.append(0)
            trilatrad.append([])
            trilatrad[len(matrix) - 1].append(0)
            trilatrad[len(matrix) - 1].append(0)
            trilatrad[len(matrix) - 1].append(0)
            delta.append(0)
            A.append(0)
            B.append(0)
            x0.append(0)
            y0.append(0)

            break
        # print(matrix)

    cord = [[10, 20], [20, 20], [20, 30], [10, 30]]

    for i in range(len(matrix)):
        if accumulatedDisp[i] >= 3:
            accuCord = argsort(matrix[i][1:])[:3]
            corx1[i] = cord[accuCord[0]][0]
            cory1[i] = cord[accuCord[0]][1]
            corx2[i] = cord[accuCord[1]][0]
            cory2[i] = cord[accuCord[1]][1]
            corx3[i] = cord[accuCord[2]][0]
            cory3[i] = cord[accuCord[2]][1]
            trilat_dist1[i] = 10 ** ((-77.0 + float(matrix[i][accuCord[0] + 1])) / (10 * 2))
            trilat_dist2[i] = 10 ** ((-77.0 + float(matrix[i][accuCord[1] + 1])) / (10 * 2))
            trilat_dist3[i] = 10 ** ((-77.0 + float(matrix[i][accuCord[2] + 1])) / (10 * 2))
            delta[i] = 4 * (corx1[i] - corx2[i]) * (cory1[i] - cory3[i]) - (corx1[i] - corx3[i]) * (
                    cory1[i] - cory2[i])
            A[i] = trilat_dist2[i] ** 2 - trilat_dist1[i] ** 2 - corx2[i] ** 2 + corx1[i] ** 2 - cory2[i] ** 2 + cory1[
                i] ** 2
            B[i] = trilat_dist3[i] ** 2 - trilat_dist1[i] ** 2 - corx3[i] ** 2 + corx1[i] ** 2 - cory3[i] ** 2 + cory1[
                i] ** 2
            x0[i] = (1 / delta[i]) * (2 * A[i] * (cory1[i] - cory3[i]) - 2 * B[i] * (cory1[i] - cory2[i]))
            y0[i] = (1 / delta[i]) * (2 * B[i] * (corx1[i] - corx2[i]) - 2 * A[i] * (corx1[i] - corx3[i]))

            trilatrad[i][0] = trilat_dist1[i]
            trilatrad[i][1] = trilat_dist2[i]
            trilatrad[i][2] = trilat_dist3[i]

            print("x0:");
            print(x0)
            print("y0:");
            print(y0)
            print(trilatrad)
            print(matrix)
            x0arr = np.asarray(x0)
            y0arr = np.asarray(y0)

            plot(x0arr, y0arr, trilatrad[i])
            #plt.close()
            #plt.scatter(corx1[1], cory1[1])
            #plt.scatter(corx2[1], cory2[1])
            #plt.scatter(corx3[1], cory3[1])
            #plt.scatter(x0[1], y0[1])
            #plt.legend({'d1', 'd2', 'd3', 'beacon'})
            #plt.show()
