###########################
#Libraries
###########################
import math
import serial
import matplotlib.pyplot as plt
import serial.tools.list_ports
import codecs
import numpy as np
from pyqtgraph.Qt import QtGui, QtCore
import pyqtgraph as pg
import sys
import localization as lx
from datetime import datetime
import time
################################################
#Indoor Localisation using Trilateration and BLE
############Daniel Nguy#########################
#########Monash University######################
######Electrical and Computer###################
##########Systems Engineering###################
################################################
################################################
#########Change inputs and run##################
################################################

###########################
#Input coordinates of dispenser 1,2,3,4
###########################
dispx = [0,2.6,-1.5,0]
dispy = [4,4,7,0]

###########################
#Choose localisation method
###########################
#Method 1 Trilateration 1
#Method 2 Trilateration library
#Method 3 Trilateration 2
method = 2 

###########################
#Data file
###########################
file1 = open("RSSI_DATA.txt","a")

###########################
#Global
###########################
global IoTflag
IoTflag=True
global target
#target = 'C0:DA:84'
target = 'None'#'A0:67:AA'
global curve, plotdata

###########################
#Initialisation to plot to graph
###########################
ser = None
dt = 0.00001  # Time delta in milliseconds
element_count = 0
curves = list()
curve_xdata = list()
size = 500
buffersize = 2*500
cFactor = 1
flag = 0

###########################
#Multilateration Initialisation
###########################
P=lx.Project(mode='2D',solver='LSE')
P.add_anchor('D1',(dispx[0],dispy[0]))
P.add_anchor('D2',(dispx[1],dispy[1]))
P.add_anchor('D3',(dispx[2],dispy[2]))
cord = [[dispx[0],dispy[0]],[dispx[1],dispy[1]],[dispx[2],dispy[2]],[dispx[3],dispy[3]]]
t,label=P.add_target()


###########################
#Graph window configuration
###########################
pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')
n = 1000
datap = np.random.normal(size=(2, n))
# Create the main application instance
app = QtGui.QApplication(sys.argv)  # Create QApplication ***
# Create the view
view = pg.PlotWidget()
view.resize(800, 600)
view.setWindowTitle('Location Map of beacon')
view.setAspectLocked(True)
view.show()
size = 500
buffersize = 2*500

###########################
#########GUI###############
###########################

def poll_button(lineedit):
    return(lineedit.text())


def poll_button2(lineedit):
    return(lineedit.text())


def find_length(ser):
    elements = 0
    for x in range(5):
        line = ser.readline()
        csv = line.decode().split(',')
        elements += len(csv)
    return elements/5

def qlewrapper():
    global element_count
    serial_number = poll_button(t1)
    comport = 'COM'+str(serial_number)
    global ser
    global target

    ser = serial.Serial(port=comport, baudrate=115200, bytesize=serial.EIGHTBITS, parity=serial.PARITY_NONE, timeout=2)
    print(comport)
    target = poll_button2(t2)
    print(target)
    if (target == "Demo"):
        target = "A0:67:AA"
    element_count = int(math.ceil(find_length(ser)))
    print("There are", element_count, "values in the CSV")

def qlewrapper2():
    global target
    target = poll_button2(t2)
    print(target)
    if (target == "Demo"):
        target = "A0:67:AA"

def make_curves(x, px):
    global element_count, curves, curve_xdata, buffersize
    for x in range(element_count):
        curves[x] = px.plot()
        curve_xdata[x] = np.zeros(buffersize+1, int)


def shift_elements(buffer, csv):
    global size, buffersize, element_count
    i = buffer[buffersize]
    buffer[i] = buffer[i+size] = csv[0]
    buffer[buffersize] = i = (i+1) % size


def close_port():
    global ser
    if (ser != None):
        ser.close()


def close_app():
    close_port()
    sys.exit()


def IoT_tog():
    global IoTflag
    IoTflag = not IoTflag
    print("IoT is " +str(IoTflag))

######################################################
#Scatter Plot of Beacons#############################
######################################################
# Create the scatter plot and add it to the view
scatter_portable = pg.ScatterPlotItem(pen=pg.mkPen(width=5, color='r'), symbol='o', size=1)
view.addItem(scatter_portable)
scatter_anchor = pg.ScatterPlotItem(pen=pg.mkPen(width=5, color='b'), symbol='o', size=1)
view.addItem(scatter_anchor)

def plot(x,y,dispx,dispy,rad,n,close,close2,flag):
    # Convert data array into a list of dictionaries with the x,y-coordinates
    radius = [5 ,5 ,5 ,5]
    xc = np.append(x,[5])
    yc = np.append(y,[5])
    #print(xc)
    #print(yc)

	#Plot Coordinates
    radius[0] = (((xc[0] - dispx[0]) ** 2 + (yc[0] - dispy[0]) ** 2) ** (1 / 2)) * 4.5
    radius[1] = (((xc[0] - dispx[1]) ** 2 + (yc[0] - dispy[1]) ** 2) ** (1 / 2)) * 4.5
    radius[2] = (((xc[0] - dispx[2]) ** 2 + (yc[0] - dispy[2]) ** 2) ** (1 / 2)) * 4.5
    radius[3] = (((xc[0] - dispx[3]) ** 2 + (yc[0] - dispy[3]) ** 2) ** (1 / 2)) * 4.5
        #print(radius)
		
	#If flagged inaccuracy use RSSI to determine position
    if (radius[0] < 500 and radius[1] < 10000 and radius[2] < 10000):
        scatter_anchor.setData(dispx, dispy, size=[radius[0], radius[1], radius[2], radius[3]])
        #scatter_anchor.setData(dispx, dispy, size=[10, 10, 10, 10])
        if flag==0 and close<10: #and close2<10:
            xd = dispx[close]+abs(xc/2)
            yd= dispy[close]+abs(yc/2)
            #print(xd,yd)
            scatter_portable.setData(xd,yd,size=[20,0])
        elif flag==1 and close<10 and close2<10:
            #xd = (dispx[close]-dispx[close2])/2+xc/30
            #yd= (dispy[close]-dispy[close2])/2+yc/30

            scatter_portable.setData(xc,yc,size=[10,0])
        else:
            scatter_portable.setData(xc/3 , yc/3, size=[15, 0])

        #print('Plotted beacon ', n, ' which is ', matrix[i][0])

    # Gracefully exit the application
    app.processEvents()


#Sorts values ascending order
def argsort(seq):
    #http://stackoverflow.com/questions/3382352/equivalent-of-numpy-argsort-in-basic-python/3382369#3382369
    #by unutbu
    return sorted(range(len(seq)), key=seq.__getitem__)

######################################################
######################################################
######################################################
######################################################
######################################################
######################################################
######################################################	
######################################################
#############Beacon Matrix Initialisation#############
######################################################
#####Creates a matrix with all active beacons#########
################For up to 4 dispensers################
######################################################
######################################################
######################################################
######################################################
######################################################
######################################################
######################################################
######################################################
######################################################
######################################################
x = 0
arrayDisp = []
arrayProximity = []
arrayAddress = []
arrayRSSI = []
arrayForce = []
arrayBattery = []
dispx1 = [0]
dispy1 = [0]
dispx2 = [0]
dispy2 = [0]
dispx3 = [0]
dispy3 = [0]
RSSI = []
x0plot = [0]
y0plot = [0]
arrayRSSI_last5 = []
plt.ion()
arrayRSSI_movingAvg = []
trilat_dist1 = []
trilat_dist2 = []
trilat_dist3 = []
delta = []

A = []
B = []
x0 = []
y0 = []
location = []
corx1 = []
cory1 = []
corx2 = []
cory2 = []
corx3 = []
cory3 = []
corx1.append(0)
cory1.append(0)
corx2.append(0)
cory2.append(0)
corx3.append(0)
cory3.append(0)
trilat_dist1.append(0)
trilat_dist2.append(0)
trilat_dist3.append(0)
delta.append(0)
A.append(0)
B.append(0)
location.append(0)
x0.append(0)
y0.append(0)
trilatrad = []
trilatrad.append([])
trilatrad[0].append(0)
trilatrad[0].append(0)
trilatrad[0].append(0)
timeInZone = []
actionedCountdown = []
notifiedCountdown=[]
initial = 1000.0
N= 5
matrix = []
matrix.append([])
matrix[0].append(initial)
accumulatedDisp = []
accumulatedDisp.append(0)
arrayDispNo = []
IoTMatrix = [[0,0],[0,0],[0,0],[0,0],[0,0]]
#creates matrix = [ [ ] ]


######################################################
######################################################
######################################################
######################################################
######################################################
######################################################
#################Main update loop#####################
######################################################

def update():
    global curve1, curve2,curve3,curve4
    flag = 0
	
######################################################
#Read serial in at 115200 baud rate# 
######################################################
    if (ser != None):
    #if(ser.isOpen()):
        while(1):
           # print(ser.readline())
            data = str(ser.readline())
            #print(data);
######################################################
#Poll for data, validate and split into lists#########
######################################################
            if data.find('@D') != -1:
                data = data.replace("b'@D",'')
                recvData = data.split(',')
               # print(data)
                #print(recvData)

                #do checksum here
                if len(recvData) == 4 and len(recvData[0]) ==1 and len(recvData[3])<8:
                    recvData[3] = recvData[3].replace("\\r\\n'",'')
                    #arrayDisp = int(float(recvData[0]))
                    #arrayProximity = int(float(recvData[1]))
                    #arrayAddress = str(recvData[2])
                    #arrayRSSI = int(float(recvData[3]))
                    #print(recvData)
                    if len(recvData[3])<3:
                        arrayDispNo = recvData[0]
                        arrayProximity = recvData[1]
                        arrayAddress = recvData[2]
                        arrayRSSI = recvData[3]
                        # print(recvData)
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################						
######################################################################################
#Build Matrix in form [[beacon1],[beacon2],...,[beaconx]]#############################
######################################################################################
#Form [beacon1] = [MacAddress, RSSI_D1, RSSI_D2, RSSI_D3,RSSI_D4, Closest Dispenser,timeLastAlerted, coolDownforActionPerformed]
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################
                    if(len(arrayDispNo)>0 and len(arrayRSSI)>0 and len(arrayAddress)==8):
                        for i in range(len(matrix)):  # len(input) # rows len(input[0]) # columns eg. ([1,2],[2,3],[4,1]) 3 rows 2 cols
                            current_milli_time = lambda: int(round(time.time() * 1000))
                            if (arrayAddress == matrix[i][0]):
                                if(arrayRSSI_last5[i][int(float(arrayDispNo)) - 1]==[]):
                                    #arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].append
                                    arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].append(0)
                                    arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].append(0)
                                    arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].append(0)
                                    arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].append(0)
                                    arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].append(0)
                                    arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].pop(0)
                                    arrayRSSI_last5[i][int(float(arrayDispNo)) - 1].append(int(float(arrayRSSI)))
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].pop(0)
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].append(int(float(arrayRSSI)))
                                arrayRSSI_movingAvg[i][int(float(arrayDispNo))-1] = sum(arrayRSSI_last5[i][int(float(arrayDispNo))-1])/5
                                if matrix[i][int(float(arrayDispNo))] == initial:
                                    accumulatedDisp[i] = accumulatedDisp[i] + 1
                                matrix[i][int(float(arrayDispNo))] = float(arrayRSSI_movingAvg[i][int(float(arrayDispNo))-1])

                                break

                            elif matrix[i][0] == initial:
                                matrix[i][0] = arrayAddress
                                matrix[i].append(initial);
                                matrix[i].append(initial);
                                matrix[i].append(initial);
                                matrix[i].append(initial)
                                matrix[i].append(initial) #Use this for Beacon number
                                timeInZone.append(current_milli_time())
                                actionedCountdown.append(0)
                                notifiedCountdown.append(0)
                                arrayRSSI_last5.append([])
                                arrayRSSI_last5[i].append([])
                                arrayRSSI_last5[i].append([])
                                arrayRSSI_last5[i].append([])
                                arrayRSSI_last5[i].append([])
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].pop(0)
                                arrayRSSI_last5[i][int(float(arrayDispNo))-1].append(int(float(arrayRSSI)))
                                arrayRSSI_movingAvg.append([])
                                arrayRSSI_movingAvg[i].append([])
                                arrayRSSI_movingAvg[i].append([])
                                arrayRSSI_movingAvg[i].append([])
                                arrayRSSI_movingAvg[i].append([])

                                if matrix[i][int(float(arrayDispNo))]==initial:
                                    accumulatedDisp[i] = accumulatedDisp[i]+1
                                matrix[i][int(float(arrayDispNo))] = float(arrayRSSI)
                                break
                            elif i == len(matrix) - 1:
                                matrix.append([])
                                accumulatedDisp.append(0)
                                timeInZone.append(current_milli_time())
                                actionedCountdown.append(0)
                                notifiedCountdown.append(0)
                                matrix[len(matrix) - 1].append(arrayAddress)
                                matrix[len(matrix) - 1].append(initial);
                                matrix[len(matrix) - 1].append(initial);
                                matrix[len(matrix) - 1].append(initial);
                                matrix[len(matrix) - 1].append(initial);
                                matrix[len(matrix) - 1].append(initial)
                                arrayRSSI_last5.append([])
                                arrayRSSI_last5[len(matrix) - 1].append([])
                                arrayRSSI_last5[len(matrix) - 1].append([])
                                arrayRSSI_last5[len(matrix) - 1].append([])
                                arrayRSSI_last5[len(matrix) - 1].append([])
                                arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1].append(0)
                                arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1].pop(0)
                                arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1].append(float(arrayRSSI))
                                arrayRSSI_movingAvg.append([])
                                arrayRSSI_movingAvg[len(matrix) - 1].append([])
                                arrayRSSI_movingAvg[len(matrix) - 1].append([])
                                arrayRSSI_movingAvg[len(matrix) - 1].append([])
                                arrayRSSI_movingAvg[len(matrix) - 1].append([])
                                arrayRSSI_movingAvg[len(matrix) - 1][int(float(arrayDispNo))-1] =sum(arrayRSSI_last5[len(matrix) - 1][int(float(arrayDispNo))-1])/5
                                if matrix[len(matrix) - 1][int(float(arrayDispNo))] == initial:
                                    accumulatedDisp[len(matrix) - 1] = accumulatedDisp[len(matrix) - 1] + 1
                                matrix[len(matrix) - 1][int(float(arrayDispNo))] = float(arrayRSSI_movingAvg[len(matrix) - 1][int(float(arrayDispNo))-1])
                                corx1.append(0)
                                cory1.append(0)
                                corx2.append(0)
                                cory2.append(0)
                                corx3.append(0)
                                cory3.append(0)
                                trilat_dist1.append(0)
                                trilat_dist2.append(0)
                                trilat_dist3.append(0)
                                trilatrad.append([])
                                trilatrad[len(matrix) - 1].append(0)
                                trilatrad[len(matrix) - 1].append(0)
                                trilatrad[len(matrix) - 1].append(0)
                                delta.append(0)
                                A.append(0)
                                B.append(0)
                                location.append(0)
                                x0.append(0)
                                y0.append(0)

                                break
                        #print(matrix)
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################						
######################################################################################						
#Localisation methods#################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################
#Method 1 Trilateration 1
#Method 2 Trilateration library
#Method 3 Trilateration 2
#Add any other method that can utilise three RSSI values collected
######################################################################################
######################################################################################
######################################################################################
                        for i in range(len(matrix)):
                            if accumulatedDisp[i]>=1:

                                accuCord = argsort(matrix[i][1:5])[:3]
                                #accuCord = [0,1,2]
                                #accuCord = (matrix[i][1:])[:3]
                                corx1[i] = cord[accuCord[0]][0]
                                cory1[i] = cord[accuCord[0]][1]
                                corx2[i] = cord[accuCord[1]][0]
                                cory2[i] = cord[accuCord[1]][1]
                                corx3[i] = cord[accuCord[2]][0]
                                cory3[i] = cord[accuCord[2]][1]
                                trilat_dist1[i] = 10**((-73.0+float(matrix[i][accuCord[0]+1]))/(10*2))*cFactor
                                trilat_dist2[i] = 10**((-73.0+float(matrix[i][accuCord[1]+1]))/(10*2))*cFactor
                                trilat_dist3[i] = 10**((-73.0+float(matrix[i][accuCord[2]+1]))/(10*2))*cFactor

                                if (method == 1):
                                    delta[i] = 4 * (corx1[i] - corx2[i]) * (cory1[i] - cory3[i]) - (corx1[i] - corx3[i]) * (cory1[i] - cory2[i])
                                    A[i] = trilat_dist2[i]**2 - trilat_dist1[i]**2 - corx2[i]**2 + corx1[i]**2 - cory2[i]**2+cory1[i]**2
                                    B[i] = trilat_dist3[i]**2 - trilat_dist1[i]**2 - corx3[i]**2 + corx1[i]**2 - cory3[i]**2+cory1[i]**2
                                    x0[i] = (1/delta[i])*(2*A[i]*(cory1[i]-cory3[i])-2*B[i]*(cory1[i]-cory2[i]))
                                    y0[i] = (1/delta[i])*(2*B[i]*(corx1[i]-corx2[i])-2*A[i]*(corx1[i]-corx3[i]))


                                    trilatrad[i][0] = trilat_dist1[i]
                                    trilatrad[i][1] = trilat_dist2[i]
                                    trilatrad[i][2] = trilat_dist3[i]

                                    #accumulatedDisp[i] >= 1:
                                    #print(trilat_dist1)
                                    #print(matrix)
                                    #print(trilatrad[0])
                                    #print(x0)
                                    #print(y0)
                                if(method==2):
                                    t.add_measure('D1', trilat_dist1[i])
                                    t.add_measure('D2', trilat_dist2[i])
                                    t.add_measure('D3', trilat_dist3[i])
                                    P.solve()
                                    trilatrad[i][0] = trilat_dist1[i]
                                    trilatrad[i][1] = trilat_dist2[i]
                                    trilatrad[i][2] = trilat_dist3[i]

                                    location[i] = t.loc
                                    x0[i] = location[i].x
                                    y0[i] = location[i].y
                                    #print(matrix)
                                    #print(t.loc)
                                    #print(trilatrad[0])
                                if(method==3):
                                    trilat_dist1[i] = 10 ** (
                                                (-73.0 + float(matrix[i][accuCord[0] + 1])) / (10 * 2)) * cFactor
                                    trilat_dist2[i] = 10 ** (
                                                (-73.0 + float(matrix[i][accuCord[1] + 1])) / (10 * 2)) * cFactor
                                    trilat_dist3[i] = 10 ** (
                                                (-73.0 + float(matrix[i][accuCord[2] + 1])) / (10 * 2)) * cFactor

                                    d21 = ((int(corx2[i])-int(corx1[i]))**2+(int(cory2[i])-int(cory1[i]))**2)**(1/2)
                                    d31 = ((int(corx3[i])-int(corx1[i]))**2+(int(cory3[i])-int(cory1[i]))**2)**(1/2)
                                    b21 = (trilat_dist1[i]**2-trilat_dist2[i]**2+d21**2)/2
                                    b31 = (trilat_dist1[i]**2-trilat_dist3[i]**2+d31**2)/2
                                    #b32 = (trilat_dist2[i] ** 2 - trilat_dist3[i] ** 2 + d41 ** 2) / 2

                                    Alg = np.array([[int(corx2[i])-int(corx1[i]),int(cory2[i])-int(cory1[i])],[int(corx3[i])-int(corx1[i]),int(cory3[i])-int(cory1[i])]])
                                    b = np.array([[b21],[b31]])

                                    term1 = np.linalg.pinv(np.multiply(np.transpose(Alg),Alg))
                                    term2 = np.multiply(np.transpose(Alg),b)
                                    sol = np.multiply(term1,term2)
                                    x0[i] =float(sol[0][0])
                                    y0[i] =float(sol[1][1])
                                    #print(x0[i],y0[i])
                                    #np.linalg.lstsq(A, y, rcond=None)[0]



                                    # if(arrayAddress == 'D0:74'):

									
									
######################################################################################
###If 3 dispensers reporting value for a specific beacon can plot and check #########
#####################the target beacon in GUI#########################################
######################################################################################
									
                                check = argsort(matrix[i][1:5])  # where 4 is max dispensers
                                for j in range(1, len(matrix[0]) - 1):
                                    if (int(matrix[i][j]) < 75.0 and j - 1 == int(check[0])):
                                        if (matrix[i][0] == target):
                                            # print("Portable beacon ",matrix[i][0],"at dispenser ",j)
                                            matrix[i][5] = j
                                    elif (j - 1 == int(check[0])):
                                        if (matrix[i][0] == target):
                                            # print("Portable beacon ",matrix[i][0],"not near dispenser")
                                            matrix[i][5] = 9999

                                    if (int(matrix[i][j]) < 90.0 and j - 1 == int(check[1])):
                                        if (matrix[i][0] == target):
                                            # print("Portable beacon ",matrix[i][0],"at dispenser ",j)
                                            b2 = j
                                    else:
                                        b2 = 9999

                                if(matrix[i][5]<900):
                                    if(matrix[i][int(matrix[i][5])]>100):
                                        flag = 1
                                    else:
                                        flag = 0

######################################################################################
###################################Plot Scatter and RSSI values#######################
#####################the target beacon in GUI#########################################
######################################################################################
                                if(matrix[i][0]==target):
                                    x0arr = np.asarray(x0)
                                    y0arr = np.asarray(y0)

                                    plot(x0arr[i],y0arr[i],dispx,dispy,trilatrad[0],i,matrix[i][5]-1,b2,3)#flag)

                                    buff1 = buffer1[buffersize]
                                    buffer1[buff1] = buffer1[buff1 + size] = matrix[i][1]
                                    buffer1[buffersize] = buff1 = (buff1 + 1) % size

                                    buff2 = buffer2[buffersize]
                                    buffer2[buff2] = buffer2[buff2 + size] = matrix[i][2]
                                    buffer2[buffersize] = buff2 = (buff2 + 1) % size

                                    buff3 = buffer3[buffersize]
                                    buffer3[buff3] = buffer3[buff3 + size] = matrix[i][3]
                                    buffer3[buffersize] = buff3 = (buff3 + 1) % size

                                    buff4 = buffer4[buffersize]
                                    buffer4[buff3] = buffer4[buff4 + size] = matrix[i][4]
                                    buffer4[buffersize] = buff4 = (buff4 + 1) % size

                                    curve1.setData(buffer1[buff1:buff1 + size])
                                    curve1.setPos(x, 0)

                                    curve2.setData(buffer2[buff2:buff2 + size])
                                    curve2.setPos(x, 0)

                                    curve3.setData(buffer3[buff3:buff3 + size])
                                    curve3.setPos(x, 0)

                                    curve4.setData(buffer3[buff3:buff3 + size])
                                    curve4.setPos(x, 0)
                                elif(target=='All'):
                                    x0arr = np.asarray(x0)
                                    y0arr = np.asarray(y0)
                                    plot(x0arr[0],y0arr[0],dispx,dispy,trilatrad[0],i,matrix[0][5]-1,b2,flag)

                                    buff1 = buffer1[buffersize]
                                    buffer1[buff1] = buffer1[buff1 + size] = matrix[0][1]
                                    buffer1[buffersize] = buff1 = (buff1 + 1) % size

                                    buff2 = buffer2[buffersize]
                                    buffer2[buff2] = buffer2[buff2 + size] = matrix[0][2]
                                    buffer2[buffersize] = buff2 = (buff2 + 1) % size

                                    buff3 = buffer3[buffersize]
                                    buffer3[buff3] = buffer3[buff3 + size] = matrix[0][3]
                                    buffer3[buffersize] = buff3 = (buff3 + 1) % size

                                    buff4 = buffer4[buffersize]
                                    buffer4[buff3] = buffer4[buff4 + size] = matrix[0][4]
                                    buffer4[buffersize] = buff4 = (buff4 + 1) % size

                                    curve1.setData(buffer1[buff1:buff1 + size])
                                    curve1.setPos(x, 0)

                                    curve2.setData(buffer2[buff2:buff2 + size])
                                    curve2.setPos(x, 0)

                                    curve3.setData(buffer3[buff3:buff3 + size])
                                    curve3.setPos(x, 0)

                                    curve4.setData(buffer3[buff3:buff3 + size])
                                    curve4.setPos(x, 0)
#################################################################################
###Saves with timestamp the beacon Matrix ######### ######### ######### #########
##################### ######### ######### #######################################
#################################################################################

                                dateTimeObj = datetime.now()
                                timestampStr = dateTimeObj.strftime("%d-%b-%Y (%H:%M:%S.%f)")
                                matrix_str = ''.join(str(e) for e in matrix)

                                file1.write(timestampStr+": "+matrix_str+'\n')

#################################################################################
###Dispensing Action monitoring and cooldown######### ######### ######### #########
########Alerts if actionedCountdown and notifiedCountdown exists##################
#################################################################################

                                if(current_milli_time()-timeInZone[i] > 10000 and current_milli_time()-actionedCountdown[i]>100000 and current_milli_time()-notifiedCountdown[i]>1000000):

                                    ser.write(('!D{},{}{}'.format(matrix[i][5],matrix[i][0],'\r\n')).encode('utf-8'))
                                    print("Notified: ",matrix[i][5])
                                    notifiedCountdown[i]=current_milli_time()
                                if (matrix[i][0] == target):
                                    print(matrix[i])

                                if(target=='All'):
                                    print(matrix)

                    if(len(matrix)>0):
                        for i in range(len(matrix)):
                            if matrix[i][0]==target:
                                break;

                            if len(matrix)==i and matrix[len(matrix)][0]!=target:
                                print("Could not find target with address " +str(target))
                                exit()

##################### ######### ######### #######################################
#################################################################################
##################### ######### ######### #######################################
#################################################################################								
#Poll and Build IoT Matrix in form [[IoTbeacon1],[IoTbeacon2],...,[IoTbeaconx]]###############
#Form [IoTbeacon1] = [straingauageVal , Batterylife]
##################### ######### ######### #######################################
##################### ######### ######### #######################################
#################################################################################								
								
            if data.find('%D') != -1:
                data = data.replace("b'%D", '')
                recvData2 = data.split(',')
                        # print(data)
                        # print(recvData)

                        # do checksum here
                if len(recvData2) == 4 and len(recvData2[0]) == 1 and len(recvData2[3]) < 8:
                    recvData2[3] = recvData2[3].replace("\\r\\n'", '')
                            # arrayDisp = int(float(recvData[0]))
                            # arrayProximity = int(float(recvData[1]))
                            # arrayAddress = str(recvData[2])
                            # arrayRSSI = int(float(recvData[3]))
                            # print(recvData)
                    if len(recvData2[2]) < 3:
                        feedbackdispNo = recvData2[0]
                        feedbackAddress = recvData2[1]
                for i in matrix:
                    if(matrix[i][0]==feedbackAddress):
                        actionedCountdown[i]=current_milli_time();
                        ser.write(('!D{},{}{}'.format(matrix[i][5], matrix[i][0], '\r\n')).encode('utf-8'))
            if data.find('#D') != -1:
                data = data.replace("b'#D", '')
                recvData3 = data.split(',')
                if len(recvData3) == 3 and len(recvData3[0]) >=1 and len(recvData3[2])<15:
                    recvData3[2] = recvData3[2].replace("\\r\\n'",'')
                    #arrayDisp = int(float(recvData[0]))
                    #arrayProximity = int(float(recvData[1]))
                    #arrayAddress = str(recvData[2])
                    #arrayRSSI = int(float(recvData[3]))
                    #print(recvData)
                    if len(recvData3[2])<10:
                        arrayDispNo_IoT = recvData3[0]
                        arrayForce = recvData3[1]
                        arrayBattery = recvData3[2]
                    if(len(arrayDispNo_IoT))>0:
                        IoTMatrix[int(float(arrayDispNo_IoT))][0]=float(arrayForce)
                        IoTMatrix[int(float(arrayDispNo_IoT))][1]=float(arrayBattery)
                if(IoTflag):
                    print(IoTMatrix)

				
#################################################################################			
#################################################################################
###GUI launch####################################################################
#################################################################################
#################################################################################
##########
#if __name__ == '__main__':
#    if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
#        app.exec_()  # Start QApplication event loop ***

if not QtGui.QApplication.instance():
    app = QtGui.QApplication([])
else:
    app = QtGui.QApplication.instance()

win = QtGui.QWidget()
win.setWindowTitle("RSSI plot")
win.resize(1000, 600)
layout = QtGui.QGridLayout()
win.setLayout(layout)

b1 = QtGui.QPushButton("Start")
b1.clicked.connect(qlewrapper)

b2 = QtGui.QPushButton("Close port")
b2.clicked.connect(close_port)

b3 = QtGui.QPushButton("IoT Poll")
b3.clicked.connect(IoT_tog)

b4 = QtGui.QPushButton("Target")
b4.clicked.connect(qlewrapper2)

t1 = QtGui.QLineEdit("Enter Device Serial")
t2 = QtGui.QLineEdit("Enter Target")

p1 = pg.PlotWidget()
p1.setRange(yRange=[-128, -20])
p1.addLegend()
p1.showGrid(x=True, y=True, alpha=0.8)
p1.setLabel('left', 'RSSI dBm')

curve1 = p1.plot(pen='y', name="Disp1")
curve2 = p1.plot(pen='g', name="Disp2")
curve3 = p1.plot(pen='b', name="Disp3")
curve4 = p1.plot(pen='r', name="Disp4")
buffer1 = np.zeros(buffersize+1, int)
buffer2 = np.zeros(buffersize+1, int)
buffer3 = np.zeros(buffersize+1, int)
buffer4 = np.zeros(buffersize+1, int)

layout.addWidget(p1, 0, 0, 1, 3)
layout.addWidget(b1, 1, 0)
layout.addWidget(t1, 1, 1)
layout.addWidget(t2, 2, 1)
layout.addWidget(b2, 1, 2)
layout.addWidget(b3, 2, 2)
layout.addWidget(b4, 2, 0)

timer = QtCore.QTimer()
timer.timeout.connect(update)
timer.start(dt)
timer.setInterval(dt)
# if(ser != None):
#  timer.stop()
win.show()
app.exec_()


#################################################################################